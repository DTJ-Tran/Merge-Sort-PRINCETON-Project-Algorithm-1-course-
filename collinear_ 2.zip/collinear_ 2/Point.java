import java.util.Comparator;
import edu.princeton.cs.algs4.StdDraw;

public class Point implements Comparable<Point> {
   private final int x; // x coordinate
    private final int y; // y coordinate
    

    public Point(int x, int y) {
     // constructs the point (x, y)
      this.x = x;
      this.y = y;
    }           

    public void draw()  {
        StdDraw.point(x, y); // draws the point
    }      

    public void drawTo(Point that) {
        StdDraw.line(this.x,this.y,that.x,that.y);   // draws the line segment from this point to that point
    }                 
  
    public String toString() {
        return "(" + x + ", " + y + ")" ;  // string representation       
    }                         
 
    public int compareTo(Point that)
        // compare two points by y-coordinates, breaking ties by x-coordinates
    {   
        if (y > that.y) 
        {
            return 1;
        }
        else if (y == that.y) 
        {
            if (x > that.x) 
            {
                return 1;
            }
            else if (x == that.x) 
            {
                return 0;
            }
            else
            {
                return -1;
            }
        }
        else {
            return -1;
        }
        
        
    }
    public double slopeTo(Point that) {
        // the slope between this point and that point

        if (that == null) {
           throw new NullPointerException("The argument to the method is null");
        }
       
        int deltaX = that.x - x ; 
        int deltaY = that.y - y;

        if (x == that.x) {
            if (y == that.y) 
            {
            return Double.NEGATIVE_INFINITY; // Degenerate line segment (between a point and itself)
           } 
            return Double.POSITIVE_INFINITY; // Vertical line segment
        } 
        else if (this.y == that.y) 
        { 
           return 0; // Horizontal line segment
        }
        return (double) deltaY / deltaX; // Calculate the slope   
    }    

    public Comparator<Point> slopeOrder()  {
        return new SlopeOrder(this); // return a comparator object
    }
    private class SlopeOrder implements Comparator<Point> {
        private Point referencePoint;

        public SlopeOrder(Point r) {
            this.referencePoint = r;
        }

        public int compare(Point p, Point q) {

            if (p == null || q == null) {
                throw new NullPointerException("Arguments cannot be null");
            }
            
            double slope1 = referencePoint.slopeTo(p);
            double slope2 = referencePoint.slopeTo(q);

            if (Double.isInfinite(slope1) && Double.isInfinite(slope2) &&((slope1 > 0 && slope2 > 0)||(slope1 < 0 && slope2 < 0))) {
                return 0; // slopes are both infinity
            }
            if (Double.isInfinite(slope1) && Double.isInfinite(slope2) && slope1 < 0 && slope2 > 0) {
                return -1;  
            } else if (Double.isInfinite(slope1) && Double.isInfinite(slope2) && slope1 > 0 && slope2 < 0) {
                return 1;
            }

            if (slope1 < slope2) {
                 return -1; // slopeToP is less than slopeToQ
             } else if (slope1 > slope2) {
                return 1;  // slopeToP is greater than slopeToQ
             } else {
                return 0; //Points are collinear
            }  // check for antisymetric and transitive comparision
            
            }
         
     }  
    }      
  
          

    
 

      

       
    
    

