import java.util.ArrayList;
import java.util.Arrays;
import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.StdDraw;

public class FastCollinearPoints {
    private LineSegment[] segments;

     
    public FastCollinearPoints(Point[] points) 
    {
        checkNull(points);
        Point[] sortedPoints = Arrays.copyOf(points,points.length);
        Point[] pointsCopy = Arrays.copyOf(points, points.length);
        ArrayList<LineSegment> segmentList = new ArrayList<LineSegment>();
        Arrays.sort(pointsCopy);
        checkDuplicate(points);

        for (int i = 0; i < pointsCopy.length; ++i) 
        {
            Point origin = pointsCopy[i];
            Arrays.sort(sortedPoints);
            Arrays.sort(sortedPoints, origin.slopeOrder());
            int count = 1; // The reference point itself
            Point lineBeginning = null;

            for (int j = 0; j < sortedPoints.length -1 ; ++j) 
            {
                if (sortedPoints[j].slopeTo(origin) == sortedPoints[j+ 1].slopeTo(origin)) 
                {
                    count++;
                    if (count ==2) 
                    {
                        lineBeginning = sortedPoints[j];
                        count++; // The second point
                    } 
                    else if (count >= 4 && j + 1 == sortedPoints.length - 1)  // The last point
                    {
                        if (lineBeginning.compareTo(origin) > 0) 
                        {
                            segmentList.add(new LineSegment(origin, sortedPoints[j+1]));
                        }
                        count = 1; // Reset the count
                    }
                } 
                else if (count >= 4) 
                {
                    if (lineBeginning.compareTo(origin) > 0) 
                    {
                        segmentList.add(new LineSegment(origin, sortedPoints[j]));
                    }
                    count = 1; // Reset the count
                }
                else 
                {
                    count = 1; // Reset the count
                }
             
            }
           
        }
        
        segments = segmentList.toArray(new LineSegment[segmentList.size()]); // Creat the list hold the segments
        

    }


    public int numberOfSegments() {
        return segments.length;
    }

    public LineSegment[] segments() {
        return Arrays.copyOf(segments, numberOfSegments());
    }

    private void checkNull(Point[] points) {
        if (points == null) {
            throw new IllegalArgumentException("points cannot be null");
             }

     for (Point p : points) {
           if (p == null) {
                     throw new IllegalArgumentException("points cannot contain null entries");
                 }
             }
    }

    private void checkDuplicate(Point[] points) {

        for (int i = 0; i < points.length - 1 ; ++i) {
            if (points[i].compareTo(points[i+1]) == 0) {
                throw new IllegalArgumentException("Duplicate points found");
            } 
        }
    }

}
    /*
     
      public static void main(String[] args) {
        // read the n points from a file
        In in = new In(args[0]);
        int n = in.readInt();
        Point[] points = new Point[n];
        for (int i = 0; i < n; i++) {
            int x = in.readInt();
            int y = in.readInt();
            points[i] = new Point(x, y);
        }

        // draw the points
        StdDraw.enableDoubleBuffering();
        StdDraw.setXscale(0, 32768);
        StdDraw.setYscale(0, 32768);
        for (Point p : points) {
            p.draw();
        }
        StdDraw.show();

        // print and draw the line segments
        FastCollinearPoints collinear = new FastCollinearPoints(points);
        for (LineSegment segment : collinear.segments()) {
            StdOut.println(segment);
            segment.draw();
        }
        StdDraw.show();
    }
}
     */

  
