import java.util.Arrays;
import java.util.Scanner;

public class BruteCollinearPoints_1 {

    private Point[] points;

    public BruteCollinearPoints_1(Point[] points) {
        this.points = points.clone();
    }

    public LineSegment[] segments() {
        LineSegment[] segments = new LineSegment[0];

        for (int i = 0; i < points.length; i++) {
            for (int j = i + 1; j < points.length; j++) {
                for (int k = j + 1; k < points.length; k++) {
                    for (int l = k + 1; l < points.length; l++) {
                        if (points[i].slopeTo(points[j]) == points[j].slopeTo(points[k]) &&
                                points[j].slopeTo(points[k]) == points[k].slopeTo(points[l])) {
                            segments = Arrays.copyOf(segments, segments.length + 1);
                            segments[segments.length - 1] = new LineSegment(points[i], points[l]);
                        }
                    }
                }
            }
        }

        return segments;
    }

    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            int n = scanner.nextInt();
            Point[] points = new Point[n];

            for (int i = 0; i < n; i++) {
                int x = scanner.nextInt();
                int y = scanner.nextInt();
                points[i] = new Point(x, y);
            }

            BruteCollinearPoints_1 bruteCollinearPoints = new BruteCollinearPoints_1(points);
            LineSegment[] segments = bruteCollinearPoints.segments();

            for (LineSegment segment : segments) {
                System.out.println(segment);
            }
        }
    }
}
