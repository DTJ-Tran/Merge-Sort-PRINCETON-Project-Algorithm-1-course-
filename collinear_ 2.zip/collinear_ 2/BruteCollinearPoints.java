

import java.util.Arrays;
public class BruteCollinearPoints {  

private LineSegment[] segments;
private int index;
private Object[] segmenObjects;

    public BruteCollinearPoints(Point[] points)    // finds all line segments containing 4 points
    {   
        
         if (points == null) {
               throw new IllegalArgumentException("points cannot be null");
                }
 
        for (Point p : points) {
              if (p == null) {
                        throw new IllegalArgumentException("points cannot contain null entries");
                    }
                }
            
            
        if (checkDuplicate(points)) {
            throw new IllegalArgumentException("points cannot be repeated");
        }

        int n = points.length;
        segmenObjects = new LineSegment[n]; // main focus: not to use the array of LineSegment - because cause the additional loops and memory leak - checkDuplicate method
        int index = 0;
    

        for (int i = 0; i < n ; i++) {
            for (int j = i+1; j < n ; j++) {
                for (int k = j+1; k < n ; k++) {
                    for (int l = k+1; l < n; l++) {

                      Point p = points[i];
                      Point q = points[j];
                      Point r = points[k];
                      Point s = points[l];

                      double slope[] = new double[3];

                      slope[0] = p.slopeTo(q);
                      slope[1] = p.slopeTo(r);
                      slope[2] = p.slopeTo(s);

                      if(slope[0] == slope[1] && slope[0] == slope[2]) {
                        Point[] tuple = new Point[] {p, q, r,s};
                        Arrays.sort(tuple);
                        segmenObjects[index] = new LineSegment(tuple[0], tuple[3]);
                        index++; // need to increase the index to add the next element
                        if (index == segmenObjects.length) {
                            resize(2 * index);
                        }
                    }
                }
            }
        }
     }
        segments = new LineSegment[index];
        for (int i = 0; i < index; i++) {
            segments[i] = (LineSegment) segmenObjects[i];
        }
    }
    
    public int numberOfSegments() // the number of line segments
    {
        return segments.length;
    } 

    public LineSegment[] segments() // the line segments
    {
        LineSegment[] lineSegments = new LineSegment[numberOfSegments()];
        System.arraycopy(segments, 0, lineSegments, 0, numberOfSegments());

        return lineSegments;   
    }

    private boolean checkDuplicate (Point[] points) {
        if (points.length > 0) {
            Point[] pointsCopy = new Point[points.length];
            System.arraycopy(points, 0, pointsCopy, 0, points.length);
            Arrays.sort(pointsCopy);
            Point currentPoint = pointsCopy[0];
            for (int i = 1; i < pointsCopy.length; i++) {
                if (pointsCopy[i].compareTo(currentPoint) == 0) {
                    return true;
                } else {
                    currentPoint = pointsCopy[i];
                }
            }
            return false;
        } else {
            return false;
        }
    }
  
    
       
   private void resize(int capacity) {
    assert capacity >= index;
    if (capacity  > index) {
        Point[] temp = new Point[capacity];
        System.arraycopy(segmenObjects, 0, temp, 0, index);
        segmenObjects = temp;
    }

   }

}

   

